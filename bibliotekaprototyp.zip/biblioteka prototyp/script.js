function toggleMenu(){
  document.querySelector(".topic-sidebar").classList.toggle("a");
}
function closeMenu(){
  document.querySelector(".topic-sidebar").classList.remove("a");
}
var container = document.getElementById("container");
container.addEventListener('click', function (){
    closeMenu()
  })
var menuBtn = document.getElementsByClassName('burger')[0];

  menuBtn.addEventListener('click', function () {
    toggleMenu();
  });





function checkedCompletedTopic() {
  topics.classList.add("CompletedIcon");
  topics.classList.remove("RightLessIcon");
    
}

function topicSelect(pageName)
{
  document.getElementById('container').innerHTML=" ";
  $('#container').load(pageName+'.html');
  toggleMenu();
}

//-----------SO---------------//

$(document).ready(function () {
  $('#menu1').click(function () {
    topicSelect("menu1");
   });
});
$(document).ready(function () {
  $('#menu2').click(function () {
    topicSelect("menu2");
   });
});
$(document).ready(function () {
  $('#menu3').click(function () {
    topicSelect("menu3");
   });
});
$(document).ready(function () {
  $('#menu4').click(function () {
    topicSelect("menu4");
   });
});