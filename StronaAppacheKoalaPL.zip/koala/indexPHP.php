<!DOCTYPE html>
<html lang="pl">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Świat Koali</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <header>
      <h1>Świat Koali</h1>
      <nav>
        <ul>
          <li><a href="index.html" >Test HTML</a></li>
          <li><a href="indexPHP.php" class="active">Test PHP</a></li>
          <li><a href="indexMySQL.php">Test MySQL</a></li>
        </ul>
      </nav>
    </header>
    <main>
      
        <h2 class="bad <?php echo 'good';?>">Interpreter PHP działa poprawnie</h2>
            <p>jeżeli widzisz tu jakieś błędy to masz coś źle</p>
    </main>
    <footer>Copyright by Zbrzeźniak Kamil</footer>
  </body>
</html>
