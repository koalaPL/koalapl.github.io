-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 17 Maj 2023, 13:40
-- Wersja serwera: 10.4.24-MariaDB
-- Wersja PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `biblioteka`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `adresy`
--

CREATE TABLE `adresy` (
  `identyfikator` int(11) NOT NULL,
  `ulica` text COLLATE utf8mb4_polish_ci NOT NULL,
  `nr_domu` int(11) NOT NULL,
  `miejscowosc` text COLLATE utf8mb4_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `adresy`
--

INSERT INTO `adresy` (`identyfikator`, `ulica`, `nr_domu`, `miejscowosc`) VALUES
(1, 'Polna', 37, 'Gdańsk'),
(2, 'Polna', 56, 'Gdańsk'),
(3, 'Francuska', 89, 'Gdańsk'),
(4, 'Miodowa', 12, 'Kraków'),
(6, 'Elo', 1, 'Gdańsk'),
(7, 'Marszałka3', 3, 'Gdańsk'),
(15, 'Marszałka32', 32, 'Gdańsk'),
(16, 'Handlowa', 761, 'Warszawa');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `mieszkancy`
--

CREATE TABLE `mieszkancy` (
  `identyfikator` int(11) NOT NULL,
  `imie` text COLLATE utf8mb4_polish_ci NOT NULL,
  `nazwisko` text COLLATE utf8mb4_polish_ci NOT NULL,
  `identyfikator_adresu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `mieszkancy`
--

INSERT INTO `mieszkancy` (`identyfikator`, `imie`, `nazwisko`, `identyfikator_adresu`) VALUES
(2, 'Marcin', 'Bąk', 1),
(3, 'Ela', 'Tkacz', 2),
(5, 'Bernard', 'Aloise', 3),
(7, 'Artur', 'Poniatowski', 7),
(8, 'Jan', 'Brzechwa', 15);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownicy`
--

CREATE TABLE `pracownicy` (
  `identyfikator` int(11) NOT NULL,
  `imie` text COLLATE utf8mb4_polish_ci NOT NULL,
  `nazwisko` text COLLATE utf8mb4_polish_ci NOT NULL,
  `login` text COLLATE utf8mb4_polish_ci NOT NULL,
  `haslo` text COLLATE utf8mb4_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `przyjezdni`
--

CREATE TABLE `przyjezdni` (
  `identyfikator` int(11) NOT NULL,
  `imie` text COLLATE utf8mb4_polish_ci NOT NULL,
  `nazwisko` text COLLATE utf8mb4_polish_ci NOT NULL,
  `identyfikator_adresu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `przyjezdni`
--

INSERT INTO `przyjezdni` (`identyfikator`, `imie`, `nazwisko`, `identyfikator_adresu`) VALUES
(1, 'Karol', 'Kowalski', 4),
(2, 'Anita', 'Brzozowska', 16);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `repertuar`
--

CREATE TABLE `repertuar` (
  `identyfikator` int(11) NOT NULL,
  `autor` text COLLATE utf8mb4_polish_ci NOT NULL,
  `tytul` text COLLATE utf8mb4_polish_ci NOT NULL,
  `data_wydania` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `repertuar`
--

INSERT INTO `repertuar` (`identyfikator`, `autor`, `tytul`, `data_wydania`) VALUES
(1, 'George Orwell', 'Rok 1984', '1949-01-01'),
(2, 'Dave Eggers', 'Wstrząsające dzieło kulejącego geniusza', '2017-06-07'),
(3, 'Stephen Hawking', 'Krótka historia czasu', '2022-02-22'),
(4, 'Sue Lynn Tan', 'Serce Wojownika Słońca', '2023-05-16');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wypozyczenia`
--

CREATE TABLE `wypozyczenia` (
  `identyfikator_ksiazki` int(11) NOT NULL,
  `identyfikator_klienta` int(11) NOT NULL,
  `data_wypozycznia` date NOT NULL,
  `data_zwrotu` date NOT NULL,
  `czy_mieszkaniec` tinyint(1) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Zrzut danych tabeli `wypozyczenia`
--

INSERT INTO `wypozyczenia` (`identyfikator_ksiazki`, `identyfikator_klienta`, `data_wypozycznia`, `data_zwrotu`, `czy_mieszkaniec`, `id`) VALUES
(1, 1, '2023-03-09', '2023-05-16', 0, 1),
(3, 3, '2023-05-01', '2023-05-17', 1, 2),
(2, 8, '2023-05-17', '0000-00-00', 0, 3);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `adresy`
--
ALTER TABLE `adresy`
  ADD PRIMARY KEY (`identyfikator`);

--
-- Indeksy dla tabeli `mieszkancy`
--
ALTER TABLE `mieszkancy`
  ADD PRIMARY KEY (`identyfikator`);

--
-- Indeksy dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD PRIMARY KEY (`identyfikator`);

--
-- Indeksy dla tabeli `przyjezdni`
--
ALTER TABLE `przyjezdni`
  ADD PRIMARY KEY (`identyfikator`);

--
-- Indeksy dla tabeli `repertuar`
--
ALTER TABLE `repertuar`
  ADD PRIMARY KEY (`identyfikator`);

--
-- Indeksy dla tabeli `wypozyczenia`
--
ALTER TABLE `wypozyczenia`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `adresy`
--
ALTER TABLE `adresy`
  MODIFY `identyfikator` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT dla tabeli `mieszkancy`
--
ALTER TABLE `mieszkancy`
  MODIFY `identyfikator` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  MODIFY `identyfikator` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `przyjezdni`
--
ALTER TABLE `przyjezdni`
  MODIFY `identyfikator` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `repertuar`
--
ALTER TABLE `repertuar`
  MODIFY `identyfikator` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `wypozyczenia`
--
ALTER TABLE `wypozyczenia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
